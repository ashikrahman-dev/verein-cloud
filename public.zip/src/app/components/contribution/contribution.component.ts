import { Component } from '@angular/core';

@Component({
  selector: 'app-contribution',
  imports: [],
  template: `
    <p>
      contribution works!
    </p>
  `,
  styles: ``
})
export class ContributionComponent {

}
